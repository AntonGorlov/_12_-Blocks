//
//  AGStudent.h
//  HomeWork Lesson 12 (Blocks)
//
//  Created by Anton Gorlov on 31.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^PatientBlock) (void);


@interface AGStudent : NSObject 
@property (strong,nonatomic) NSString* name;
@property (strong,nonatomic) NSString*lastName;
@property (assign,nonatomic) float temperature;

-(BOOL) howAreYou;
-(void) takePill;
-(void) makeShot;

-(void) PatientFeelsBad:(PatientBlock) patientsBlock;
@end
