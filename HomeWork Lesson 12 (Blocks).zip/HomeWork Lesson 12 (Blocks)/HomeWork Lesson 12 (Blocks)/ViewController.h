//
//  ViewController.h
//  HomeWork Lesson 12 (Blocks)
//
//  Created by Anton Gorlov on 31.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

