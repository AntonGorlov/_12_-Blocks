//
//  AppDelegate.m
//  HomeWork Lesson 12 (Blocks)
//
//  Created by Anton Gorlov on 31.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGStudent.h"


typedef NSString* (^myBlockWithParametrs)(NSString*);//соз собственный тип блоков



@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //Уровень ученик Фактически это повторить первую половину.
/*
    1. В апп делегате создайте блок с без возвращаемой переменной и без параметров и вызовите его.
    2. Создайте блоки с параметрами и передайте туда строку, которую выведите на экран в последствии.
    3. (сделал 3 пункт со 2-м )Если вы не определили тип данных для ваших блоков, то сделайте это сейчас и используйте их
    4. Создайте метод который принимает блок и вызывает его и вызовите этот метод.
*/
    
/*1.
     В апп делегате создайте блок с без возвращаемой переменной и без параметров и вызовите его.

    void(^firstBlock)(void);
    firstBlock=^ {
        NSLog(@"My first block");
    };
    
    firstBlock ();
    
*/
    
/*2. 
     Создайте блоки с параметрами и передайте туда строку, которую выведите на экран в последствии.
    
    NSString*firstString=[self myBlockWithParametrs:@"number 2"];
    NSLog(@"%@",firstString);
    
 */
    
/*4. Создайте метод который принимает блок и вызывает его и вызовите этот метод.

    
    [self testBlockMethod:^{
        NSLog(@"Block");
    }];
*/
    
    //Уровень Студент.http://vk.com/topic?act=browse_images&id=-58860049_1094
    /* 5. Создайте класс студент с проперти имя и фамилия.
       6. Создайте в аппделегате 10 разных студентов, пусть у парочки будут одинаковые фамилии.
       7. Поместите всех в массив.
       8. Используя соответствующий метод сортировки массива (с блоком) отсортируйте массив студентов сначала по фамилии, а если они одинаковы то по имени.
     */
    
//6. Создайте в аппделегате 10 разных студентов, пусть у парочки будут одинаковые фамилии.

    AGStudent*student1=[[AGStudent alloc]init];
    student1.name=@"Anton";
    [student1 setLastName:@"Gorlov"];
    
    AGStudent*student2=[[AGStudent alloc]init];
    student2.name=@"Stepan";
    [student2 setLastName:@"Nikolenko"];
    
    AGStudent*student3=[[AGStudent alloc]init];
    student3.name=@"Vova";
    [student3 setLastName:@"Chelombitko"];
    
    AGStudent*student4=[[AGStudent alloc]init];
    student4.name=@"Ibragim";
    [student4 setLastName:@"Dialo"];
    
    AGStudent*student5=[[AGStudent alloc]init];
    student5.name=@"Denis";
    [student5 setLastName:@"Gorlov"];
    
    AGStudent*student6=[[AGStudent alloc]init];
    student6.name=@"Ivan";
    [student6 setLastName:@"Nikolenko"];
    
    AGStudent*student7=[[AGStudent alloc]init];
    student7.name=@"Petro";
    [student7 setLastName:@"Sagaidachniy"];
    
    AGStudent*student8=[[AGStudent alloc]init];
    student8.name=@"Pamela";
    [student8 setLastName:@"Anderson"];
    
    AGStudent*student9=[[AGStudent alloc]init];
    student9.name=@"Angelina";
    [student9 setLastName:@"Jolie"];
    
    AGStudent*student10=[[AGStudent alloc]init];
    student10.name=@"Any";
    [student10 setLastName:@"Lorak"];

//7.
    NSArray* students = [NSArray arrayWithObjects:
                         student1,
                         student2,
                         student3,
                         student4,
                         student5,
                         student6,
                         student7,
                         student8,
                         student9,
                         student10
                         ,nil];
 

//8.Используя соответствующий метод сортировки массива (с блоком) отсортируйте массив студентов сначала по фамилии, а если они одинаковы то по имени.

students=[students sortedArrayUsingComparator:^NSComparisonResult(id   obj1, id obj2) {
    if ([obj1 lastName]==[obj2 lastName]) {
        return [[obj1 name] compare:[obj2 name]];
    }else {
     return [[obj1 lastName] compare:[obj2 lastName]];
    }
}];
    for (AGStudent* student in students) {
        NSLog(@"%@ %@\n",student.name, student.lastName);
    }

/*
    Мастер.
    9. Задание из видео. Из урока о делегатах. У пациентов удалите протокол делегат и соответствующее проперти.
    10. Добавьте метод принимающий блок когда им станет плохо.
    11. Блок должен передавать указатель на самого студента ну и на те параметры, которые были в задании по делегатам.
    12. Теперь когда пациентам поплохеет, они должны вызывать блок, а в блоке нужно принимать решения что делать (доктор не нужен делайте все в апп делегате)
 */

#pragma mark - Master
    student1.temperature=36.6f;
    student2.temperature=37.1f;
    student3.temperature=38.2f;
    student4.temperature=40.8f;
    student5.temperature=41.4f;
    student6.temperature=36.9f;
    student7.temperature=37.0f;
    student8.temperature=37.7f;
    student9.temperature=37.3f;
    student10.temperature=38.0f;
    
    
    for (AGStudent* student in students){
        void(^doctorBlock)(void)=^{
            NSLog(@"Students %@ feels bad ",student.lastName);
            if (student.temperature >=37.f && student.temperature <=39.f){
            [student takePill];
             }else if (student.temperature >39.f){ //else if используем когда больше 2-х сравнений
                [student makeShot];
            }else{
                NSLog(@"Patient %@ take it easy",student.name);
            }
        };
        NSLog(@"Good morning,%@ are you okey?",student.name);
        if(![student howAreYou]) {
            NSLog(@"Doctor, i'm sick");
            [student PatientFeelsBad:doctorBlock];
        }else {
            NSLog(@"Yes,I'm okey");
        }
        NSLog(@"\n");
    }
 
/*
 Супермен.
 13. Познайте истинное предназначение блоков :) Пусть пациентам становится плохо не тогда когда вы их вызываете в цикле(это убрать), а через случайное время 5-15 секунд после создания (используйте специальный метод из урока по селекторам в ините пациента).
 14. не забудьте массив пациентов сделать проперти аппделегата, а то все помрут по выходе из функции так и не дождавшись :)
 Не знаю как делать!!!!!!
 */

  
    return YES;
}

-(NSString*)myBlockWithParametrs:(NSString*) string {
    return [NSString stringWithFormat:@"block with parametrs %@",string]; //блок для 2го пункта в условии (Ученик).
};

-(void) testBlockMethod:(void (^)(void)) testBlock { //4й пункт(Ученик)
    NSLog(@"testBlockMethod");
    testBlock();
   }

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
