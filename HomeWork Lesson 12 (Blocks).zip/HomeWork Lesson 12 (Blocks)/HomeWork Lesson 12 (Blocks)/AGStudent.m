//
//  AGStudent.m
//  HomeWork Lesson 12 (Blocks)
//
//  Created by Anton Gorlov on 31.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGStudent.h"

@implementation AGStudent : NSObject


-(BOOL) howAreYou {
    BOOL imOk=arc4random()%2;
    return imOk;
 }

-(void) takePill{
    NSLog(@"%@ %@ takes a pill",self.name,self.lastName);
}
-(void) makeShot{
    NSLog(@"%@ %@ makes a shot",self.name,self.lastName);
}


-(void)PatientFeelsBad:(PatientBlock) blockFeels {
        blockFeels (); //вызывается блок,который передан в метод
}


@end
