//
//  AppDelegate.m
//  BlocksTest (Lesson 12)
//
//  Created by Anton Gorlov on 28.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AppDelegate.h"
#import "AGObject.h"

typedef void (^OurTestBlock)(void);
typedef NSString*(^OurTestBock2)(NSInteger);

@interface AppDelegate () //категория
@property (copy,nonatomic) OurTestBlock testBlock;




@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
/*1.
   // [self  testMethod];
    //соз блок который ничего не принимает и не передает.
   
    void(^testBlock)(void);
    testBlock=^{
        NSLog(@"test Block");
    };
    testBlock();//чтобы вызвать блок (ничего не принимает и не передает)
    testBlock();
 
    //[self testMethodWithParams:@"Test with params" value:101];
    void (^testBockWithParams)(NSString*,NSInteger)=^(NSString*string, NSInteger intValue){
        NSLog(@"testBockWithParams %@, %ld",string,intValue );
        };
    testBockWithParams (@"Test string",785);
 
    //метод возвращающий параметры
    NSString* result=[self testMethodWithReturnValueAndParams:@"Test String" value:4];
    NSLog(@"%@",result);
 
    //соз блоки ,которые принимают и возвращают
    NSString*(^testBlockWithReturnValueAndParams)(NSString*,NSInteger)=^(NSString*string,NSInteger intValue){
        return [NSString stringWithFormat:@"testBlockWithReturnValueAndParams %@ ,%ld",string,intValue];
    };
    NSString*result2=testBlockWithReturnValueAndParams (@"Test string",4);
    NSLog(@"%@",result2);
*/
/*2.
    __block NSString*testString=@"How is it pissible?";//__ если хотим изменить строку в блоке.Инициалировали строку
    __block NSInteger i=0; //__ если хотим изменить переменные в блоке.
    void(^testBlock2)(void);
    testBlock2=^{
        
        NSLog(@"test block");
       // NSLog(@"%@",testString);
        i=i+1; //др вариант записи NSLog(@"%ld",++i); приметивный тип
        // NSLog(@"%ld",i);
        testString=[NSString stringWithFormat:@"How is it pissible? %ld",i]; // изменение строки
        NSLog(@"%@",testString); //выводим на экран
    };
    testBlock2();
    testBlock2();
    testBlock2();
    testBlock2();
*/
/*3.
    //как вызвать наш метод с блоками??? 1-й способ
    
    [self testBlocksMethod:^{
        NSLog(@"Block");
    }];
 
    //2-й способ взвать метод
    
    void (^bbb)(void)=^{
        NSLog(@"Block");
    };
    [self testBlocksMethod:bbb];
*/
    
/*4.
    //мы можем создавать собственный тип блоков!!
   
    OurTestBlock testBlock=^{
        NSLog(@"Block2");
    };
    [self testBlocksMethod2:testBlock];
  
    OurTestBock2 tb=^(NSInteger intValue){
        return [NSString stringWithFormat:@"%ld",intValue];
    };
    NSLog(@"%@",tb(5));
*/
    
    AGObject* obj=[[AGObject alloc]init];
    obj.name=@"Object";
    
    __weak AGObject* weakObj=obj;//соз указатель на теже самые данные ,но с weak -ссылкой на обьект с наз obj.
    OurTestBlock tb=^{
        NSLog(@"%@",weakObj);//obj.name
    
    };
    
    self.testBlock=tb;
    self.testBlock ();//обьект не унечтожен,так как блок держит  strong-ссылку
    
    return YES;
}

-(void) testMethod {
    NSLog(@"Test method!");
}
-(void) testMethodWithParams:(NSString*) string value:(NSInteger) intValue {
    NSLog(@"testMethodWithParams %@, %ld",string,intValue);
};
//сделаем testMethodWithReturnValueAndParams который будет возвращать какуюто строку

-(NSString*) testMethodWithReturnValueAndParams:(NSString*) string value:(NSInteger) intValue {
    return [NSString stringWithFormat:@"testMethodWithReturnValueAndParams %@, %ld",string,intValue];

}
//метод принимающий блоки как параметры !!!!
-(void) testBlocksMethod:(void (^)(void)) testBlock;{
    NSLog(@"testBlocksMethod");
    testBlock();
    testBlock();
    testBlock();
}

-(void) testBlocksMethod2:(OurTestBlock) testBlock;{
    NSLog(@"testBlocksMethod2");
    testBlock();
  
}


- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
