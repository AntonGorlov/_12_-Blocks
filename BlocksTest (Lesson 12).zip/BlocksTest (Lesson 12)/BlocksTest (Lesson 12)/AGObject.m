//
//  AGObject.m
//  BlocksTest (Lesson 12)
//
//  Created by Anton Gorlov on 30.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "AGObject.h"



@implementation AGObject
-(void) dealloc {
    NSLog(@"AGObject is deallocated");
}


@end
