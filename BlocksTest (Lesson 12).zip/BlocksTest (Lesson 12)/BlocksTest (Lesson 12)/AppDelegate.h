//
//  AppDelegate.h
//  BlocksTest (Lesson 12)
//
//  Created by Anton Gorlov on 28.10.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

